package com.github.davidmoten.xsdforms;

/**
 * Exists solely to force generation of javadoc so maven release plugin doesnt' fail.
 **/
public class Ignore {

}
