package com.github.davidmoten.xsdforms.store;

public class Datastore {

}
